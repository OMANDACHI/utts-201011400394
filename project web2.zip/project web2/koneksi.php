<?php
// Membuat koneksi
$koneksi = mysqli_connect("localhost", "root", "", "shop_db");


?>
