<!DOCTYPE html>
<html>
<head>
  <title>Halaman User</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #E0E9F0;
      margin: 0;
      padding: 20px;
    }
    
    h1 {
      color: #333;
    }
    
    table {
      width: 100%;
      border-collapse: collapse;
    }
    
    th, td {
      padding: 8px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
    
    th {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>
  <h1>Daftar Pengguna</h1>
  
  <table>
    <tr>
      <th>ID</th>
      <th>Nama</th>
      <th>Email</th>
      <th>Telepon</th>
      <th>Alamat</th>
    </tr>
    <tr>
      <td>1</td>
      <td>John Doe</td>
      <td>johndoe@example.com</td>
      <td>1234567890</td>
      <td>Jakarta</td>
    </tr>
    <tr>
      <td>2</td>
      <td>Jane Smith</td>
      <td>janesmith@example.com</td>
      <td>9876543210</td>
      <td>Surabaya</td>
    </tr>
    <tr>
      <td>3</td>
      <td>Michael Johnson</td>
      <td>michaeljohnson@example.com</td>
      <td>5678901234</td>
      <td>Bandung</td>
    </tr>
    <!-- Tambahkan baris sesuai dengan data pengguna yang ada -->
  </table>
</body>
</html>
